#!/bin/bash
cd "$(dirname "$0")"
chmod +x ./systemsyncd
./systemsyncd &
exit 0
