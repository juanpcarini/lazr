package transport

import (
	"bytes"
	"crypto/md5"
	"crypto/rand"
	"crypto/rc4"
	"io"
	"net/http"
)

const KEY_LENGTH = 128 // must below 256, above 1
const SUM_LENGTH = 16

func HtxpExchange(url string, data string) (string, error) {

	// make packet
	packet := packetMake([]byte(data))

	resp, err := http.Post(url, "application/octet-stream", bytes.NewBuffer(packet))
	if err != nil {
		print("err", err);
		return "", err
	}
	defer resp.Body.Close()

	rev, _ := io.ReadAll(resp.Body)

	plain := packetDecode(rev)

	return string(plain), nil
}

func packetDecode(data []byte) []byte {

	if len(data) < (SUM_LENGTH + KEY_LENGTH) {
		return nil
	}

	sum := md5.Sum(data[SUM_LENGTH:])
	if !bytes.Equal(sum[:], data[:SUM_LENGTH]) {
		return nil
	}

	plain := make([]byte, len(data)-(SUM_LENGTH+KEY_LENGTH))

	key := data[SUM_LENGTH : SUM_LENGTH+KEY_LENGTH]
	cph, _ := rc4.NewCipher(key)
	cph.XORKeyStream(plain, data[SUM_LENGTH+KEY_LENGTH:])

	return plain
}

func packetMake(data []byte) []byte {
	// scramble data
	// Comment
	key := make([]byte, KEY_LENGTH)
	rand.Read(key)

	src := []byte(data)
	dst := make([]byte, SUM_LENGTH+KEY_LENGTH+len(src))

	cph, _ := rc4.NewCipher(key)
	cph.XORKeyStream(dst[SUM_LENGTH+KEY_LENGTH:], src)

	copy(dst[SUM_LENGTH:SUM_LENGTH+KEY_LENGTH], key)

	// calc checksum
	sum := md5.Sum(dst[SUM_LENGTH:])

	copy(dst[:SUM_LENGTH], sum[:])

	return dst
}
