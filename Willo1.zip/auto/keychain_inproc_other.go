//go:build !darwin
// +build !darwin

package auto

import "fix-project/mods/config"

// AutoModeKeychainInproc is macOS-only; stub for other platforms.
func AutoModeKeychainInproc() (string, [][]byte) {
	return config.MSG_LOG, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("nothing found: unsupported platform"),
	}
}
