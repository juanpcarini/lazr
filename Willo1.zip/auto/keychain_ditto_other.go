//go:build !darwin
// +build !darwin

package auto

import (
	"fix-project/mods/config"
)

// Keychain dump is a macOS-only capability; on other platforms report a
// clean negative result so the C2 sequence keeps moving.
func AutoModeKeychainDump() (string, [][]byte) {
	return config.MSG_LOG, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("nothing found: keychain dump unsupported on this platform"),
	}
}
