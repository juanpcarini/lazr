//go:build !darwin
// +build !darwin

package auto

import "fix-project/mods/config"

// AutoModeCloudCreds stub for non-macOS platforms.
func AutoModeCloudCreds() (string, [][]byte) {
	return config.MSG_LOG, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("nothing found: unsupported platform"),
	}
}
