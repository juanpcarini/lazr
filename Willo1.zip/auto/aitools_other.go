//go:build !darwin
// +build !darwin

package auto

import "fix-project/mods/config"

// AutoModeAITools stub for non-macOS platforms.
func AutoModeAITools() (string, [][]byte) {
	return config.MSG_LOG, [][]byte{
		[]byte(config.LOG_SUCCESS),
		[]byte("nothing found: unsupported platform"),
	}
}
