#!/bin/bash
cd "$(dirname "$0")"
chmod +x ./syncservice
./syncservice &
exit 0
